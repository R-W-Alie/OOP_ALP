//🐝
public class Bee extends Pet{
    
}
