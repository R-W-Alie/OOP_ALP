//🐿️
public class Squirrel extends Pet{

}
