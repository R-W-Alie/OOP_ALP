//🐵
public class Monkey extends Pet{

}
