//🦜
public class Bird extends Pet{
    
}
