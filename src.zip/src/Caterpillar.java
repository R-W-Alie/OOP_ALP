//🐛
public class Caterpillar extends Pet{
    
}
