public class MediumQuest {

}
