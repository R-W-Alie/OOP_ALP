//🐨
public class Koala extends Pet {

}
