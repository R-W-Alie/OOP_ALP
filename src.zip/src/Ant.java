//🐜
public class Ant extends Pet{
    
}
