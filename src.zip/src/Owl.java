//🦉
public class Owl extends Pet{

}
