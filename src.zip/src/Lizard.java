//🦎
public class Lizard extends Pet{
    
}
