//🦥
public class Sloth extends Pet{
    
}
