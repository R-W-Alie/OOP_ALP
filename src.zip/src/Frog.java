//🐸
public class Frog extends Pet{

}
