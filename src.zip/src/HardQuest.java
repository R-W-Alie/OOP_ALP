public class HardQuest {

}
