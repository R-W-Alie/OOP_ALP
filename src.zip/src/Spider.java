//🕷️
public class Spider extends Pet{
    
}
