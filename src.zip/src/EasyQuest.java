public class EasyQuest {

}
