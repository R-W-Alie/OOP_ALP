//🐍
public class Snake extends Pet{
    
}
